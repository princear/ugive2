import {
    View,
    Image,
    PermissionsAndroid,
    ActivityIndicator,
    ImageBackground,
    StyleSheet,Button,
    Platform,
    Text,
    TextInput, BackHandler,
    Alert,Input,
    TouchableOpacity,
    Linking, SafeAreaView,
    ScrollView, FlatList
  } from "react-native";
  import React, { Component } from "react";
  import { Table, Row, Rows, TableWrapper, Cell } from 'react-native-table-component';
  import { Picker } from '@react-native-picker/picker';
  import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
  import Header from '../Components/Header/index'
  import { ApiScreen } from "../API/ApiScreen";
  import AsyncStorage from "@react-native-community/async-storage";
  import Modal from 'react-native-modal';
  import Contacts from 'react-native-contacts';
  import CheckBox from '@react-native-community/checkbox';

  var selectedTags = [];
  let st;

  export default class BulkUpload extends Component {
  
    constructor(props) {
      super(props);
      this.state = {

        uniqueArray:[],
        firstname: '',
        text:'',
        
        lastname: '',
        email: '',
        mobile: '',
        refer: '',
        isLoading: false,
        id: '',
        current_fund: '',
        dataSource: [],
        isVisible: true,
        isPrivate: false,
        dataSource2: '',
        
      }
      this.arrayholder = [];
  
    }
  
    
    async componentDidMount() {
        
             this.setState({
        isLoading: true
      })

        if (Platform.OS === "android") {
          PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.READ_CONTACTS, {
            title: "Contacts",
            message: "This app would like to view your contacts."
          }).then(() => {
            setTimeout(() => {
  
                this.setState({
                  isLoading: false,
                 
                })
                this.loadContacts();
              }, 2000)
           
          });
        
        } else {

            setTimeout(() => {
  
                        this.setState({
                          isLoading: false,
                         
                        })

                        this.loadContacts();
                      }, 2000)
                      
        }
      }
    
      async loadContacts() {
    
        await Contacts.getAll((err,contacts) => {
    
         if(err === 'denied'){
            // console.log('err')
    
         }

    
         else{

           let newArray = contacts
         let uniqueArray = [...new Set(newArray)]

        //   let uniqueArray = newArray.filter( (ele, ind) => ind === newArray.findIndex( elem => elem.id === ele.id && elem.givenName === ele.givenName))

           this.setState({
             uniqueArray: uniqueArray,
             
            },() => {
              this.arrayholder = uniqueArray
            })
           
          console.log('>>>>>>>>>>>',uniqueArray)

         }
    
        })
        
         //Contacts.checkPermission();
       
       }

       
    // componentDidMount = async () => {
  
    //   this.setState({
    //     isLoading: true
    //   })
  
  
  
    //   const login = await AsyncStorage.getItem('login');
    //   //console.log("dashboard", login);
  
    //   let data = JSON.parse(login);
    //   //  console.log('#################3',data)
    //   this.access_token = data.token
    //   //console.log('%%%%%%%%%%%%%%%%%%%%%%',this.access_token);
  
    //   const meurl = ApiScreen.base_url + ApiScreen.me
    //   console.log("url:" + meurl);
  
    //   fetch(meurl,
    //     {
    //       method: 'POST',
    //       headers: new Headers({
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'token': this.access_token
    //         // <-- Specifying the Content-Type
  
    //       }),
  
  
    //     }).then(response => response.json())
    //     .then((responseJson) => {
    //       // console.log('getting data from fetchaaaaaaaaaaa',responseJson.data.current_fund)
  
    //       setTimeout(() => {
  
    //         this.setState({
    //           isLoading: false,
    //           // dataSource:responseJson.data,
    //           id: responseJson.data.id,
    //           current_fund: responseJson.data.current_fund
    //         })
    //       }, 2000)
    //       console.log('%%%%%%%%%%%%%%%%%%%%%%%', this.state.id, this.state.current_fund)
    //     })
    //     .catch(error => console.log(error))
  
  
  
  
    //   const url = ApiScreen.base_url + ApiScreen.get_donorlist
    //   console.log("url:" + url);
    //   fetch(url,
    //     {
    //       method: 'POST',
    //       headers: new Headers({
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'token': this.access_token
    //         // <-- Specifying the Content-Type
  
    //       }),
  
    //       body: JSON.stringify(
    //         {
  
    //           donatee_id: '1182',
    //           fund_id: '122'
  
    //         })
  
  
    //     }).then(response => response.json())
    //     .then((responseJson) => {
    //       // console.log('getting data from fetchaaaaaaaaaaa',responseJson.data)
  
    //       setTimeout(() => {
    //         this.setState({
    //           isLoading: false,
    //           dataSource: responseJson.data,
  
    //         })
    //       }, 2000)
  
    //     })
    //     .catch(error => console.log(error))
  
  
  
  
    //   const url2 = ApiScreen.base_url + ApiScreen.fund_list;
    //   console.log("url>>>>>>>>>>:" + url2);
    //   fetch(url2,
    //     {
    //       method: 'POST',
    //       headers: new Headers({
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'token': this.access_token
    //         // <-- Specifying the Content-Type
  
    //       }),
  
  
    //     }).then(response => response.json())
    //     .then((responseJson) => {
    //       // console.log('FUND LIST>>>>>>>>>>>>>>>>',responseJson.data[0].organization)
  
    //       setTimeout(() => {
    //         this.setState({
    //           isLoading: false,
    //           dataSource2: responseJson.data[0].organization,
    //           //name : responseJson.data.name,
  
    //         })
    //       }, 2000)
  
    //     })
    //     .catch(error => console.log(error))
  
  
  
  
    // }


    // onSelectionsChange = (contacts) => {
    //   // selectedFruits is array of { label, value }
    //   this.setState({ contacts })
    // }

    
    GetFlatListItem(name) {
      Alert.alert(name);
    }
   
    searchData(text) {
     
      const newData = this.arrayholder.filter(item => {
        const itemData = item.givenName.toUpperCase();
     
        const textData = text.toUpperCase();
       
        return itemData.indexOf(textData) > -1
      });
   
      this.setState({
        uniqueArray: newData,
        text: text
        })
      }
   
      itemSeparator = () => {
        return (
          <View
            style={{
              height: .5,
              width: "100%",
              backgroundColor: "#000",
            }}
          />
        );
      }
   
  
    Add_New_Donor = async () => {
      console.log('Add new donoe');
      const firstname = this.state.firstname;
      const lastname = this.state.lastname;
      const email = this.state.email;
      const mobile = this.state.mobile;
      const refer = this.state.refer;
      //console.log(firstname,lastname,email,mobile,refer);
  
      this.setState({
        isLoading: true
      })
  
      const login = await AsyncStorage.getItem('login');
      //console.log("dashboard", login);
  
      let data = JSON.parse(login);
      //  console.log('#################3',data)
      this.access_token = data.token;
      const addurl = ApiScreen.base_url + ApiScreen.add_donor;
      console.log(addurl, email, firstname, lastname, email, mobile, refer);
  
      fetch(addurl,
  
        {
          method: 'POST',
          headers:
          {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'token': this.access_token
          },
  
          body: JSON.stringify(
  
            {
  
              fname: firstname,
              lname: lastname,
              email: email,
              mobile: mobile,
              message: refer,
  
            })
  
        }).then((response) => response.json()).then((responseJson) => {
  
          //  console.log("from login*** ",responseJson.data);
          //  this.setState({  isLoading:false })
          console.log(responseJson.message)
          if (responseJson.response_code == 200) {
            console.log(responseJson.message)
  Alert.alert(responseJson.message);
            this.setState({ isPrivate: false })
            this.componentDidMount()
  
          }
  
          else {
  
  
            const invalid = responseJson.message
            Alert.alert(invalid);
  
          }
  
          this.setState({ ActivityIndicator_Loading: false });
  
        }).catch((error) => {
          
          this.setState({
            isLoading: false
          })
  
          console.error(error);
  
        });
  
  
    }
  
  
    Add_donor = async () => {
     // let data1;
     console.log('ADDDDDDDDDDDDDDD',selectedTags)

     this.setState({
      isLoading: true
    })


    const login = await AsyncStorage.getItem('login');
    //console.log("dashboard", login);

    let data = JSON.parse(login);
    //  console.log('#################3',data)
    this.access_token = data.token;
    const addurl1 = ApiScreen.base_url + ApiScreen.bulkdonor;
    console.log(addurl1,selectedTags);

     let dd = JSON.stringify(selectedTags)
    //   {
        
    //     selectedTags
      
    //   })
       console.log('LLLLLLLLLLLLLLLLL',dd)
    fetch(addurl1,

      {
        method: 'POST',
        headers:
        {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'token': this.access_token
        },

        body: JSON.stringify(selectedTags)

      

      }).then((response) => response.json()).then((responseJson) => {

        //  console.log("from login*** ",responseJson.data);
          this.setState({  isLoading:false })
        console.log(responseJson.message)
        if (responseJson.response_code == 200) {
          console.log('>>>>>>>>>>>>',responseJson.message)
            Alert.alert(responseJson.message)
          this.setState({ isPrivate: false })
         
        }

        else {


          const invalid = responseJson.message
          console.log(invalid);

        }

        this.setState({ ActivityIndicator_Loading: false });

      }).catch((error) => {
        
        this.setState({
          isLoading: false
        })

        console.error(error);

      });


    }
  
    modelfalse = () => {
  
      this.setState({ isPrivate: false })
      this.componentDidMount()
  
    }
  
   
   

    renderHeader = () => (
      <View
        style={{
          backgroundColor: '#fff',
          padding: 10,
          paddingTop:15,
          alignItems: 'center',
          justifyContent: 'center'
        }}>
        <TextInput
          autoCapitalize='none'
          autoCorrect={false}
         onChangeText={this.handleSearch}
          status='info'
          placeholder='Search'
          style={{
           // borderRadius: 25,
            borderColor: '#333',
            width:wp('90%'),
            height:hp('6%'),
            backgroundColor: '#fff',
            borderWidth:1
          }}
          textStyle={{ color: '#000' }}
        />
      </View>
    )

    handleSearch = text => {
      console.log(text)
   //   const formattedQuery = text.toLowerCase()
     // const data = filter(this.state.fullData, user => {
       // return this.contains(user, formattedQuery)
      //})
      //this.setState({ data, query: text })
    }

    // contains = ({ name, email }, query) => {
    //   const { first, last } = name
    //   if (first.includes(query) || last.includes(query) || email.includes(query)) {
    //     return true
    //   }
    //   return false
    // }
     onchecked(name,obj){
        
     console.log('%%%%%%%%%%%%%%%%%%%%%',name,obj)
     console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',name)
      
     var fname = '';
      var lname = '';

     if(name != '' && name != null)

     {
        var nameArr =  name.split(' ');
        fname = nameArr[0];
        if(nameArr.length > 1)
        {
           lname = nameArr[nameArr.length-1];
        }
      }

     if(fname != '' )
     {

    obj['fname'] = fname;
    obj['lname'] = lname;
    obj['email'] = "";
    obj['mobile'] = obj.number;
    obj['message'] = 'Hi'
  
     }

     console.log('mmmmmmmmmmmmmmm',obj)
    
  
 
      const data = this.state.uniqueArray
      const index = data.findIndex(x => x.givenName === name)

      data[index].checked = !data[index].checked
      this.setState(data)

      
        
      const products = [...this.state.uniqueArray,selectedTags];
   

       // console.log('productssssssss',selectedTags)

      // for (var i = 0; i < selectedTags.length; i++) {

      //   console.log('%%%%%%%%%%%%%%%%',selectedTags[i])
      //     //   ss +=  selectedTags[i];
            
      //    }
      //let a = {};
      
      //a['name'] = id;
      //name.push(a)\
      
     

       products[index] = selectedTags.push(obj)
       this.setState({ products });


    //    let ss = [];
    //   for (var i = 0; i < selectedTags.length; i++) {
    //     ss +=  selectedTags[i];
        
    // }
        
    //  st = JSON.stringify(ss)

      console.log('ccsscc',selectedTags)

    
     
    }

    removeDuplicate(){
      console.log("++++++++");
      //Remove duplicate from Array list
      const newArrayList = [];
      this.state.uniqueArray.forEach(obj => {
        if (!newArrayList.some(o => o.givenName === obj.givenName)) {
          newArrayList.push({...obj});
         
        }
      });
   
      this.setState({uniqueArray: newArrayList});  
      console.log('>>>>',newArrayList)
    }
  
    render() {
  
    
      return (
        <SafeAreaView style={styles.container}>
  
          {(this.state.isLoading) &&
            <View style={{ flex: 1, justifyContent: 'center', position: 'absolute', top: '50%', left: '40%' }}>
  
              <ActivityIndicator
  
                color="#00ff00"
                size="large"
                style={{
                  backgroundColor: "rgba(204,55,57,.8)",
                  height: 80,
                  width: 80,
                  zIndex: 999,
                  borderRadius: 15
                }}
                size="small"
                color="#0000ff"
              />

            </View>}
  
          <Header
            navigation={this.props.navigation}
          />

          <View style={styles.One}>
              <Image style={styles.smsimg} source={require('../assets/26.png')} />
              <Text style={styles.text1}>Sync Contact</Text>
          </View>

          <View style={{ flexDirection: 'row', marginBottom: 20 }}>
            
            {/* <TouchableOpacity
              //onPress={() => this.Add_donor()}
            //   onPress={() => this.props.navigation.navigate('AddNewDonor', { onGoBack: () => this.refresh() })}
              style={styles.button}>
              <Text style={styles.SubmitText}>Select All</Text>
            </TouchableOpacity> */}
  
            <TouchableOpacity style={styles.button1}
             onPress={() => this.Add_donor()}>
              <Text style={{ color: '#fff', fontSize: 10, fontFamily: 'Poppins-Regular',textAlign:'center' }}>Send Now</Text>
            </TouchableOpacity>
  
          </View>
  
          <View style={styles.head}>
            <View>
  
              <Text style={styles.text}>Select</Text>
  
            </View>

            <View style={{ flex: 1 }}>
  
              <Text style={styles.text}>Name</Text>
  
            </View>

            {/* <View style={{ flex: 1 }}>
  
              <Text style={styles.text}>Contact</Text>
  
            </View> */}
           
  
          </View>
  
          {this.state.isPrivate == true && (
            // <View>
            //     <Text style={styles.privateTextStyle}>
            //       {I18n.t('add_poll.private_poll_desc')}
            //     </Text>
            //   <Text></Text>
  
            <Modal isVisible={this.state.isVisible}>
              <View style={{ flex: 1, backgroundColor: 'white' }}>
  
                <TouchableOpacity
                  onPress={() => this.modelfalse()}>
                      <Text style={styles.closemodalStyle}>X</Text>
                </TouchableOpacity>
  
                <View>
                  <Text style={{ textAlign: 'center' }}>Model</Text>
  
                  <View>
  
                    <View style={styles.searchSection}>
  
                      <TextInput autoCorrect={false}
                        onChangeText={(firstname) => this.setState({ firstname })}
                        //value='garun@delimp.com'
                        placeholder="First Name"
                        style={styles.input}>
                      </TextInput>

                    </View>
  
                    <View style={styles.searchSection}>
  
                      <TextInput autoCorrect={false}
                        onChangeText={(lastname) => this.setState({ lastname })}
                        //value='garun@delimp.com'
                        placeholder="Last Name"
                        style={styles.input}
                      >
                      </TextInput>
                    </View>
  
                    <View style={styles.searchSection}>
  
                      <TextInput autoCorrect={false}
                        onChangeText={(email) => this.setState({ email })}
                        //value='garun@delimp.com'
                        placeholder="Email Address"
                        style={styles.input}
                      >
                      </TextInput>
                    </View>
  
                    <View style={styles.searchSection}>
  
                      <TextInput autoCorrect={false}
                        onChangeText={(mobile) => this.setState({ mobile })}
                        //value='garun@delimp.com'
                        placeholder="Mobile"
                        style={styles.input}
                      >
                      </TextInput>
                    </View>
  
                    <View style={styles.searchSection}>
  
                      <TextInput autoCorrect={false}
                        onChangeText={(refer) => this.setState({ refer })}
                        //value='garun@delimp.com'
                        placeholder="How do you refer to this Person"
                        style={styles.input}
                      >

                      </TextInput>

                    </View>
  
                    <TouchableOpacity style={styles.button2}
                      onPress={() => this.Add_New_Donor()}>
                      <Text style={styles.SubmitText}>Share Your Page</Text>
                    </TouchableOpacity>
  
                  </View>
                </View>
              </View>
  
            </Modal>
  
          )}
  

  <TextInput 
         style={styles.textInput}
        onChangeText={(text) => this.searchData(text)}
         value={this.state.text}
         underlineColorAndroid='transparent'
         placeholder="Search Here" />

  <FlatList
     
     data={this.state.uniqueArray}
     keyExtractor={(item, index) => item.recordID}
   //  ItemSeparatorComponent={this.itemSeparator}
    // horizontal={true}
   // ListHeaderComponent={this.renderHeader}
     renderItem={({ item, index }) => (
     <View>
      
        {/* {item.phoneNumbers && item.phoneNumbers.length > 0 && item.phoneNumbers.map(

          (numberData,numberIndex) =>{

            return( */}

                <View style={styles.row} >
  
                <View style={{ flex: 1 }}>

                

                 <CheckBox
                
           value={item.checked}
          // onValueChange={Alert.alert(this.item.givenName)}

          onValueChange={() => {this.onchecked(item.givenName,item.phoneNumbers[0])}}
         
          style={styles.checkbox}
        
        /> 

                </View>
               

                <View style={{ flex: 1 }}>

                <Text style={styles.text2}>{item.givenName}</Text>

                </View>

                {/* <View style={{ flex: 1 }}>

                  <Text style={styles.text2}>{item.phoneNumbers[0].number}</Text>

                </View> */}
               


              </View>

            
        {/* //     )

        //   }
        // )
        
        // } */}
           
     </View>
     
      )}
     />

          {/* <FlatList
  
            data={this.state.dataSource}
            keyExtractor={(item, index) => index}
            // horizontal={true}
  
            renderItem={({ item, index }) => (
  
  
              <TouchableOpacity onPress={() => this.props.navigation.navigate('ManageDonorList', { onGoBack: () => this.refresh() })}>
                <View style={styles.row} >
  
                  <View style={{ flex: 1 }}>
  
                    <Text style={styles.text2}>{item.name}</Text>
  
                  </View>
  
                  <View style={{ flex: 1 }}>
  
                    <Text style={styles.text2}>{item.pledge_amt}</Text>
  
                  </View>
                  <View style={{ flex: 1 }}>
  
                    <Text style={styles.text2}>{item.offline_amt}</Text>
  
                  </View>
                  <View style={{ flex: 1 }}>
  
                    <Text style={styles.text2}>{item.donation_amt}</Text>
  
                  </View>
  
  
                </View>
              </TouchableOpacity>
            )}
          />
  
   */}
  
          {/* <Table style={styles.table}>
            <Row data={this.state.tableHead} style={styles.head} textStyle={styles.text}/>
            <Rows dataSource={this.state.dataSource && this.state.dataSource} style={styles.row} textStyle={styles.text2}/>
          </Table>  */}
  
  
        </SafeAreaView>
      )
    }
  }
  
  const styles = StyleSheet.create({
  
    container: {
      flex: 1,
      backgroundColor: '#fff'
  
    },
    button2: {
      backgroundColor: '#CC3739',
      padding: 15,
      width: wp('75%'),
      borderRadius: 30,
      marginLeft: 20,
      marginTop: 20,
      marginBottom: 10
  
    },
    SubmitText: {
      textAlign: 'center',
      fontFamily: 'Poppins-Regular',
      color: '#fff',
      fontSize: 16
    },
  
    closemodalStyle: {
  
      fontSize: 18,
      borderRadius: 50,
      width: 30,
      height: 30,
      textAlign: 'center',
      alignSelf: 'flex-end'
  
    },
  
    table: {
  
      width: wp('90%'),
      justifyContent: 'center',
      alignSelf: 'center'
  
    },
  
    head: {
  
      height: 40,
      borderRadius: 20,
      backgroundColor: '#F2F2F2',
      flexDirection: 'row',
      justifyContent: 'center',
      alignSelf: 'center'
  
    },
    row:
    {
      borderBottomWidth: 1,
      borderBottomColor: '#D1D1D1',
      flexDirection: 'row',
      //  width:800,
      //flexDirection:'row-reverse'
    },
    pickerContainer: {
      color: '#6C6C6C',
      width: wp('35%'),
      borderWidth: 1,
      borderRadius: 30,
      justifyContent: 'center',
      backgroundColor: '#F2F2F2',
      borderColor: '#F2F2F2',
      marginLeft: wp('5%'),
      paddingLeft: 10,
  
      fontFamily: 'Poppins-SemiBold',
  
    },
    input: {
      width: wp('75%'),
      //textAlign:'center',
      backgroundColor: '#fff',
      fontFamily: 'Poppins-Regular',
      alignSelf: 'center',
      borderWidth: 1,
      marginTop: 10,
      borderColor: '#424242',
  
      //  borderRadius:30,
      //  backgroundColor:'red'
    },
    searchSection: {
  
  
    },
  
    button: {
      backgroundColor: '#CC3739',
      padding: 8,
      width: wp('30%'),
      borderRadius: 30,
      marginLeft: 10,
  
      alignSelf: 'center'
  
    },
  
    button1: {
      backgroundColor: '#CC3739',
      padding: 8,
      width: wp('22%'),
      borderRadius: 30,
      marginLeft: 10,
  
      alignSelf: 'center'
  
    },
  
    SubmitText: {
      textAlign: 'center',
      fontFamily: 'Poppins-Regular',
      color: '#fff',
      fontSize: 10
    },
    text: {
  
      fontFamily: 'Poppins-SemiBold',
      fontSize: 12,
  
      justifyContent: 'center',
      alignSelf: 'center',
      padding: 10
  
    },
    text2: {
  
      fontFamily: 'Poppins-Regular',
      fontSize: 10,
      //alignSelf:'center',
      padding: 10
    },
  
    One: {
      flexDirection: 'row',
      padding: 30,
      marginTop: 20
    },
  
    smsimg: {
      height: 20,
      width: 20,
  
    },
    text1: {
      fontFamily: 'Poppins-SemiBold',
      fontSize: 20,
      paddingLeft: 10
    },
  
  })
  